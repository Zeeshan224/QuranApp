package com.example.newstatussaver.data

data class Para(
    val id: Int,
    val verses: List<QuranResponse>, // This holds all verses for the Para
    val title: String
)
