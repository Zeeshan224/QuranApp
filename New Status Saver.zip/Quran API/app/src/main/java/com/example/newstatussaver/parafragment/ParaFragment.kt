package com.example.newstatussaver.parafragment

import android.content.ContentValues.TAG
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.newstatussaver.QuranViewModel
import com.example.newstatussaver.R
import com.example.newstatussaver.databinding.FragmentParaBinding

class ParaFragment : Fragment() {

    private lateinit var adapter: ParaAdapter
    private lateinit var quranViewModel: QuranViewModel
    private lateinit var binding: FragmentParaBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentParaBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        quranViewModel = ViewModelProvider(this)[QuranViewModel::class.java]
        binding.recyclerView.layoutManager = LinearLayoutManager(requireContext())

        quranViewModel.quranData.observe(viewLifecycleOwner) { paras ->
            paras?.let {

                Log.d("API", "API Data Received: $it")

                adapter = ParaAdapter(it) { para ->
                    val action = ParaFragmentDirections.actionParaFragmentToDetailsFragment(para.id)
                    findNavController().navigate(action)
                }
                binding.recyclerView.adapter = adapter
            } ?: run {
                Log.d("API", "API Data is null or empty")
            }
        }
//        quranViewModel.errorMessage.observe(viewLifecycleOwner, Observer { error->
//            binding.errorTextView.text = error
//        })
        quranViewModel.getQuranData()
    }
}