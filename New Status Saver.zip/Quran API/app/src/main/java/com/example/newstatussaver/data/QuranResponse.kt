package com.example.newstatussaver.data

data class QuranResponse(
    val chapter: Int,
    val verse: Int,
    val text: String
)
