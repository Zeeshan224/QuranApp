package com.example.newstatussaver.network

import com.example.newstatussaver.data.QuranResponse
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET

interface QuranApiService {
    @GET("dev")
    suspend fun getQuran():Response<QuranResponse>

    companion object {
        private const val BASE_URL = "https://api.quran.gading/"

        fun create(): QuranApiService {
            val retrofit = Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create()) // If you're using Gson for JSON
                .build()

            return retrofit.create(QuranApiService::class.java)
        }
    }
}
