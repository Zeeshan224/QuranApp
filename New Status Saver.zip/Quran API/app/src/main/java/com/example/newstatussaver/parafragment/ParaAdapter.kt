package com.example.newstatussaver.parafragment

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.view.menu.MenuView.ItemView
import androidx.recyclerview.widget.RecyclerView
import com.example.newstatussaver.data.Para
import com.example.newstatussaver.databinding.FragmentParaBinding
import com.example.newstatussaver.databinding.ItemParaBinding

class ParaAdapter(
    private val paras: List<Para>,
    private val onClick: (Para) -> Unit
) : RecyclerView.Adapter<ParaAdapter.ParaViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ParaViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val binding: ItemParaBinding = ItemParaBinding.inflate(inflater,parent,false)
        return ParaViewHolder(binding)
    }

    override fun getItemCount(): Int = paras.size

    override fun onBindViewHolder(holder: ParaViewHolder, position: Int) {
        val para = paras[position]
        holder.bind(para,onClick)
    }

    class ParaViewHolder(private val binding: ItemParaBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(para: Para, onClick: (Para) -> Unit) {
            binding.apply{
                tvParaName.text = para.title
                root.setOnClickListener{onClick(para)}
            }
        }
    }
}