package com.example.newstatussaver.data

import com.example.newstatussaver.network.QuranApiService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import retrofit2.Response

class QuranRepository(private val apiService: QuranApiService) {
    suspend fun fetchQuranData(): (List<Para>?) {
        return withContext(Dispatchers.IO) {
            try {
                val response: Response<QuranResponse> = apiService.getQuran()
                if (response.isSuccessful) {
                    response.body()?.let { quranResponse ->
                        convertToParas(quranResponse)
                    }
                } else {
                    null
                }
            } catch (e: Exception) {
                null
            }
        }
    }

    private fun convertToParas(response: QuranResponse): List<Para> {
        return listOf()
    }
}