package com.example.newstatussaver

import android.util.Log
import android.view.WindowInsetsAnimation
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.newstatussaver.data.Para
import com.example.newstatussaver.data.QuranRepository
import com.example.newstatussaver.data.QuranResponse
import com.example.newstatussaver.network.QuranApiService
import com.example.newstatussaver.network.RetrofitInstance
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

//class QuranViewModel : ViewModel() {
//
//    // LiveData to observe the API response
//    private val _quranData = MutableLiveData<QuranResponse?>()
//    val quranData: LiveData<QuranResponse?> get() = _quranData
//
//    private val repository: QuranRepository = QuranRepository(QuranApiService.create())
//
//    // LiveData to observe any errors
//    private val _errorMessage = MutableLiveData<String>()
//    val errorMessage: LiveData<String> get() = _errorMessage
//
//    // Function to fetch Quran data
//    fun getQuranData() {
//        viewModelScope.launch {
//            try {
//                val response: Response<QuranResponse> = RetrofitInstance.api.getQuran()
//                if (response.isSuccessful) {
//                    _quranData.postValue(response.body())
//                } else {
//                    _errorMessage.postValue("Error: ${response.message()}")
//                }
//            } catch (e: Exception) {
//                _errorMessage.postValue("Exception: ${e.localizedMessage}")
//            }
//        }
//    }
//}

class QuranViewModel : ViewModel() {
    private val _quranData = MutableLiveData<List<Para>>()
    val quranData: LiveData<List<Para>> get() = _quranData

    private val repository: QuranRepository = QuranRepository(QuranApiService.create())

    fun getQuranData() {
        viewModelScope.launch {
            val paras = repository.fetchQuranData()
            _quranData.value = paras ?: emptyList() // Update LiveData
        }
    }
}

